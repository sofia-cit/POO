import 'dart:math';
// Mario

abstract class Combate {
  void atacar(Pokemon objetivo, Ataque movimiento);
  void mostrarAtaque();
  void recibirDanio(int cantidad,int prob_estado);
}

//clase base pokemon
abstract class Pokemon implements Combate {
  String tipo;
  String nombre;
  double vida;
  double vidaMax;
  int velocidad;

  Pokemon(this.tipo, this.nombre, num vidaInput, this.velocidad)
      : vida = vidaInput.toDouble(),
        vidaMax = vidaInput.toDouble();

  @override
  void mostrarAtaque() {
    print("$nombre se prepara para la acción.");
  }
}

// clase ataque
class Ataque {
  String tipoAtaque;
  String nombreAtaque;
  int danio;
  int prob_estado=0;
  double efectivo = 1.0;

  Ataque(this.tipoAtaque, this.nombreAtaque, this.danio,this.prob_estado);

  int calcularDanio() => (efectivo * danio).toInt();
}

// clase efectividad
class Efectividad {
  double calcularEfectividad(String tipoAtaque, String tipoEnemigo) {
    double factor = 1.0;

    const Map<String, Map<String, double>> efectividad = {
  // Ataque | Defensa: {
  'Normal': {
    'Fight':2.0,
    'Ghost':0.0,
  },
  'Fire': {
    'Fire':0.5,
    'Grass':0.5,
    'Water':2.0,
    'Rock':2.0,
    'Bug':0.5,
    'Ice':0.5,
    'Steel':0.5,
    'Ground':2.0,
  },
  'Water': {
    'Fire':0.5,
    'Water':0.5,
    'Grass':2.0,
    'Ice':0.5,
    'Steel':0.5,
    'Electric':2.0
  },
  'Electric': {
    'Electric':0.5,
    'Ground':2.0,
    'Flying':0.5,
    'Steel':0.5,
  },
  'Grass': {
    'Fire':2.0,
    'Water':0.5,
    'Electric':0.5,
    'Grass':0.5,
    'Ice':2.0,
    'Poison':2.0,
    'Ground':0.5,
    'Flying':2.0,
    'Bug':2.0,
  },
  'Ice': {
    'Fire':2.0,
    'Ice':0.5,
    'Fight':2.0,
    'Rock':2.0,
    'Steel':2.0,
  },
  'Fight': {
    'Flying':2.0,
    'Psycho':2.0,
    'Bug':0.5,
    'Rock':0.5,
    'Dark':0.5,
  },
  'Poison': {
    'Grass':0.5,
    'Fight':0.5,
    'Poison':0.5,
    'Ground':2.0,
    'Psycho':2.0,
    'Bug':0.5,
  },
  'Ground': {
    'Water':2.0,
    'Electric':0.0,
    'Grass':2.0,
    'Ice':2.0,
    'Poison':0.5,
    'Rock':0.5,
  },
  'Flying': {
    'Electric':2.0,
    'Grass':0.5,
    'Ice':2.0,
    'Fight':0.5,
    'Ground':0.0,
    'Bug':0.5,
    'Rock':2.0,
  },
  'Psycho': {
    'Fight':0.5,
    'Psycho':0.5,
    'Bug':2.0,
    'Ghost':2.0,
    'Dark':2.0,
  },
  'Bug': {
    'Fire':2.0,
    'Grass':0.5,
    'Fight':0.5,
    'Ground':0.5,
    'Flying':2.0,
    'Rock':2.0,
  },
  'Rock': {
    'Normal':0.5,
    'Fire':0.5,
    'Water':2.0,
    'Grass':2.0,
    'Fight':2.0,
    'Poison':0.5,
    'Ground':2.0,
    'Flying':0.5,
    'Steel':2.0,
  },
  'Ghost': {
    'Normal':0.0,
    'Fight':0.0,
    'Poison':0.5,
    'Bug':0.5,
    'Ghost':2.0,
    'Dark':2.0,
  },
  'Dragon': {
    'Fire':0.5,
    'Water':0.5,
    'Electric':0.5,
    'Grass':0.5,
    'Ice':2.0,
    'Dragon':2.0,
  },
  'Dark': {
    'Fight':2.0,
    'Psycho':0.0,
    'Bug':2.0,
    'Ghost':0.5,
    'Dark':0.5,
  },
  'Steel': {
    'Normal':0.5,
    'Fire':2.0,
    'Grass':0.5,
    'Ice':0.5,
    'Fight':2.0,
    'Poison':0.0,
    'Ground':2.0,
    'Flying':0.5,
    'Psycho':0.5,
    'Bug':0.5,
    'Rock':0.5,
    'Ghost':0.5,
    'Dragon':0.5,
    'Dark':0.5,
    'Steel':0.5,
  },

    
};

    if (efectividad.containsKey(tipoAtaque)) {
      final ataques = efectividad[tipoAtaque]!;
      if (ataques.containsKey(tipoEnemigo)) {
        factor = ataques[tipoEnemigo]!;
      }
    }

    return factor;
  }
}

//estados de condicion
enum EstadoCondicion {
  normal,
  quemado,
  envenenado,
  congelado,
  paralizado,
}

// clase pokemon de batalla
class PokemonBatalla extends Pokemon {
  EstadoCondicion estadoActual = EstadoCondicion.normal;
  List<Ataque> misAtaques;

  PokemonBatalla(String tipo, String nombre, num vidaInput,int velocidad, this.misAtaques)
      : super(tipo, nombre, vidaInput, velocidad);

  void recibirDanio(int cantidad,int prob_estado) {
    if (prob_estado!=0){
      Random rand = Random();
      int chance = rand.nextInt(100);
      if (chance < prob_estado) {
        if(this.estadoActual==EstadoCondicion.normal){
          if(this.tipo=="Fire"||
              this.tipo=="Dragon"){
            this.estadoActual=EstadoCondicion.quemado;
            print("$nombre se ha QUEMADO!");
          }
          else if(this.tipo=="Water"||
                  this.tipo=="Ice"||
                  this.tipo=="Grass"){
            this.estadoActual=EstadoCondicion.congelado;
            print("$nombre se ha CONGELADO!");
          }
          else if(this.tipo=="Electric"||
                  this.tipo=="Flying"||
                  this.tipo=="Steel"||
                  this.tipo=="Normal"||
                  this.tipo=="Psychic"||
                  this.tipo=="Ghost"||
                  this.tipo=="Dark"){
            this.estadoActual=EstadoCondicion.paralizado;
            print("$nombre se ha PARALIZADO!");
          }
          else if(this.tipo=="Poison"||
                  this.tipo=="Bug"||
                  this.tipo=="Ground"||
                  this.tipo=="Rock"||
                  this.tipo=="Fight"){
            this.estadoActual=EstadoCondicion.envenenado;
            print("$nombre se ha ENVENENADO!");
          }
        }
      }
    }
    vida -= cantidad;
    if (vida < 0) vida = 0;
  }

  @override
  void atacar(Pokemon objetivo, Ataque movimiento) {
    if (estadoActual == EstadoCondicion.congelado) {
      print("¡$nombre está CONGELADO y no puede moverse!");
      return;
    }

    if (estadoActual == EstadoCondicion.paralizado) {
      if (Random().nextInt(5) == 0) {//20% de probabilidad de no atacar
        print("¡$nombre está PARALIZADO y no puede atacar!");
        return;
      }
    }
     Efectividad calc = Efectividad();
    movimiento.efectivo = calc.calcularEfectividad(movimiento.tipoAtaque, objetivo.tipo);
   int danioCalculado = movimiento.calcularDanio();

    double modificadorDanio = 1.0;
    if (estadoActual == EstadoCondicion.quemado) {
      modificadorDanio = 0.5; 
      print("El ataque de $nombre se reduce a la mitad por la quemadura.");
    }
    int danioFinal = (danioCalculado * modificadorDanio).toInt();
    objetivo.recibirDanio(danioFinal,movimiento.prob_estado);

    

   

    print("\n$nombre usó ${movimiento.nombreAtaque}!");
    if (movimiento.efectivo == 0) print("¡No tuvo efecto!");
    if (movimiento.efectivo > 1) print("¡Es muy eficaz! (x${movimiento.efectivo})");
    if (movimiento.efectivo < 1) print("No es muy eficaz... (x${movimiento.efectivo})");
    
    print("Daño hecho: $danioFinal");
    print("Vida de ${objetivo.nombre}: ${objetivo.vida}/${objetivo.vidaMax}");
    }
  
  
  void finDeTurno() {
    if (estadoActual == EstadoCondicion.quemado) {
      int d = (vidaMax * 0.06).toInt();
      recibirDanio(d,0);
      print("$nombre recibe daño por quemadura (-$d HP)");
    }
    if (estadoActual == EstadoCondicion.envenenado) {
      int d = (vidaMax * 0.12).toInt();
      recibirDanio(d,0);
      print("$nombre recibe daño por veneno (-$d HP)");
    }
    if(estadoActual == EstadoCondicion.congelado){
      //posibilidad de descongelarse
      if(Random().nextInt(4)==0){//25% de probabilidad
        estadoActual = EstadoCondicion.normal;
        print("$nombre se ha DESCONGELADO.");
      }
    }
    if(estadoActual == EstadoCondicion.paralizado){
      //posibilidad de curarse
      if(Random().nextInt(10)==0){//10% de probabilidad
        estadoActual = EstadoCondicion.normal;
        print("$nombre se ha recuperado de la paralisis");
      }
  }
  }
    
}


abstract class Item {
  String nombreItem;
  String tipo;
  int cantidad;
  String descripcion;
  
  String imagenPath; 

  Item(this.nombreItem, this.tipo, this.cantidad, this.descripcion, 
      this.imagenPath 
  );

  void usar(PokemonBatalla objetivo);
}
// Clase base para curar HP
class Pocion extends Item {
  int cantidadCuracion;

  Pocion(this.cantidadCuracion, String nombre, String imagenPath)
      : super(nombre, "Curación", 1, "Restaura $cantidadCuracion HP al objetivo.",imagenPath);

  @override
  void usar(PokemonBatalla objetivo) {
    if (objetivo.vida <= 0) {
      print("${objetivo.nombre} está fuera de combate y no puede usar ${nombreItem}.");
      return;
    }
    
    double vidaAntes = objetivo.vida;
    double nuevaVida = vidaAntes + cantidadCuracion;
    
    if (nuevaVida > objetivo.vidaMax) {
      nuevaVida = objetivo.vidaMax;
    }

    objetivo.vida = nuevaVida;
    double hpCurado = nuevaVida - vidaAntes;

    print("${objetivo.nombre} usó ${nombreItem} y recuperó ${hpCurado.toStringAsFixed(0)} HP.");
    print("Vida actual: ${objetivo.vida.toStringAsFixed(0)}/${objetivo.vidaMax.toStringAsFixed(0)}");
  }
}

class PocionSimple extends Pocion {
  PocionSimple() : super(20, "Poción",'assets/images/items/pocion.png'); // Cura 20 HP
}
class SuperPocion extends Pocion {
  SuperPocion() : super(50, "Superpoción",'assets/images/items/super_pocion.png'); // Cura 50 HP
}
class Hiperpocion extends Pocion {
  Hiperpocion() : super(100, "Hiperpoción",'assets/images/items/hiper_pocion.png'); // Cura 100 HP
}

// Clase base para curar estados
abstract class CuradorEstado extends Item {
  EstadoCondicion estadoACurar;

CuradorEstado(String nombre, String descripcion, this.estadoACurar, String imagenPath)
      : super(nombre, "Estado", 1, descripcion, imagenPath);

  @override
  void usar(PokemonBatalla objetivo) {
    if (objetivo.estadoActual == estadoACurar) {
      objetivo.estadoActual = EstadoCondicion.normal;
      print("El ${nombreItem} curó el estado ${estadoACurar.name.toUpperCase()} de ${objetivo.nombre}.");
    } else {
      print("${objetivo.nombre} no está sufriendo el estado ${estadoACurar.name.toUpperCase()}.");
    }
  }
}

class Antidoto extends CuradorEstado {
  Antidoto()
      : super("Antídoto", "Cura el estado de Envenenado.", EstadoCondicion.envenenado,'assets/images/items/antidoto.png');
}

class Antiquemar extends CuradorEstado {
  Antiquemar()
      : super("Antiquemar", "Cura el estado de Quemado.", EstadoCondicion.quemado,'assets/images/items/antiquemar.png');
}
class Despertar extends CuradorEstado {
  Despertar()
      : super("Despertar", "Cura el estado de Congelado.", EstadoCondicion.congelado,'assets/images/items/despertar.png');
}
class Antiparalisis extends CuradorEstado {
  Antiparalisis()
      : super("Antiparalisis", "Cura el estado de Paralizado.", EstadoCondicion.paralizado,'assets/images/items/antiparalisis.png');
}