import 'dart:io';
import 'dart:math';

import 'Base.dart';
import 'ComportamientoRival.dart'; 

abstract class AccionTurno {}
class AccionAtacar extends AccionTurno {
  final Ataque movimiento;
  AccionAtacar(this.movimiento);
}

class AccionUsarItem extends AccionTurno {
  final Item item;
  final PokemonBatalla objetivo;
  AccionUsarItem(this.item, this.objetivo);
}

class Batalla {
  final Random _rand = Random();
  //cambios en los atributos y la eleccion
  final List<PokemonBatalla> _pokedexGeneral; 
  final ComportamientoRival _iaRival = ComportamientoRival(); 
  
  //late para inicializar despuse de la seleccion
  late PokemonBatalla _jugador;
  late PokemonBatalla _rival;
  
  List<Item> itemsUsuario;      //mochila usuario
  late List<Item> _itemsRivalActuales; //mochila rival (se inicializa despues)
  bool _enCurso = true;

  //ahora recibe la lista general de Pokémon y los items 
  Batalla(this._pokedexGeneral, this.itemsUsuario, List<Item> itemsRivalBase) {
      _itemsRivalActuales = List<Item>.from(itemsRivalBase);  

      if (_pokedexGeneral.isEmpty) {
        throw Exception("Error de Inicialización: La Pokedex no debe estar vacía.");
      }
  }
  
  bool get enCurso => _enCurso && _jugador.vida > 0 && _rival.vida > 0;

  //método para que el usuario elija su Pokémon
  void _seleccionarPersonaje() {
    print("\n--- SELECCIÓN DE PERSONAJE ---");
    for (int i = 0; i < _pokedexGeneral.length; i++) {
        print("${i + 1}. ${_pokedexGeneral[i].nombre} (Tipo: ${_pokedexGeneral[i].tipo}, HP: ${_pokedexGeneral[i].vidaMax.toStringAsFixed(0)}, VEL: ${_pokedexGeneral[i].velocidad})");
    }

    int eleccion = -1;
    while (eleccion < 1 || eleccion > _pokedexGeneral.length) {
      stdout.write("Elige tu Pokémon (1-${_pokedexGeneral.length}): ");
      String? input = stdin.readLineSync(); 
      try {
        eleccion = int.tryParse(input ?? "") ?? -1;
      } catch (e) { eleccion = -1; }
    }
    _jugador = _pokedexGeneral[eleccion - 1]; 
    print("¡Has elegido a: ${_jugador.nombre}!");
  }

  //método para que el usuario elija el rival 
  void _seleccionarRival() {
    print("\n--- SELECCIÓN DE RIVAL ---");
    //para que el rival no sea el mismo que el jugador
    List<PokemonBatalla> rivalesDisponibles = _pokedexGeneral.where((p) => p.nombre != _jugador.nombre).toList();
    
    for (int i = 0; i < rivalesDisponibles.length; i++) {
        print("${i + 1}. ${rivalesDisponibles[i].nombre} (Tipo: ${rivalesDisponibles[i].tipo}, HP: ${rivalesDisponibles[i].vidaMax.toStringAsFixed(0)}, VEL: ${rivalesDisponibles[i].velocidad})");
    }

    int eleccion = -1;
    while (eleccion < 1 || eleccion > rivalesDisponibles.length) {
      stdout.write("Elige el Pokémon RIVAL (1-${rivalesDisponibles.length}): ");
      String? input = stdin.readLineSync(); 
      try {
        eleccion = int.tryParse(input ?? "") ?? -1;
      } catch (e) { eleccion = -1; }
    }
    
    _rival = rivalesDisponibles[eleccion - 1];
    print("¡Tu rival ha elegido a: ${_rival.nombre}!");
  }

  void _ejecutarAccion(PokemonBatalla atacante, AccionTurno accion) {
    if (accion is AccionAtacar) {
      PokemonBatalla objetivo = (atacante == _jugador) ? _rival : _jugador;
      atacante.atacar(objetivo, accion.movimiento);
    } else if (accion is AccionUsarItem) {
      accion.item.usar(accion.objetivo);
    }
  }

  AccionTurno _convertirDecisionRival(String decision) {
    if (decision == "ATACAR") {
      return AccionAtacar(_iaRival.elegirAtaqueAleatorio(_rival));
    } 
    else if (decision == "USAR_ITEM_POCION") {
      for (Item item in _itemsRivalActuales) {
        if (item is Pocion && item.cantidad > 0) {
          return AccionUsarItem(item, _rival);
        }
      }
    }
    else if (decision == "USAR_ITEM_ESTADO") {
      for (Item item in _itemsRivalActuales) {
        if (item is CuradorEstado && item.cantidad > 0 && item.estadoACurar == _rival.estadoActual) {
          return AccionUsarItem(item, _rival);
        }
      }
    }
    //si no se encontró ningún item válido, atacar por defecto
    return AccionAtacar(_rival.misAtaques[0]);
  }

  //determina el orden de acción basado en la velocidad
  void determinarTurno(AccionTurno accionUsuario, AccionTurno accionRival) {
    double velocidadUsuario = _jugador.velocidad.toDouble();
    double velocidadRival = _rival.velocidad.toDouble();
    
    if (_jugador.estadoActual == EstadoCondicion.paralizado) {
      velocidadUsuario /= 2;
    }
    if (_rival.estadoActual == EstadoCondicion.paralizado) {
      velocidadRival /= 2;
    }
    
    PokemonBatalla primero;
    PokemonBatalla segundo;
    
    if (velocidadUsuario > velocidadRival) {
      primero = _jugador;
      segundo = _rival;
    } else if (velocidadRival > velocidadUsuario) {
      primero = _rival;
      segundo = _jugador;
    } else {
      //empate - decidir aleatoriamente
      if (_rand.nextBool()) {
        primero = _jugador;
        segundo = _rival;
      } else {
        primero = _rival;
        segundo = _jugador;
      }
    }
    
    AccionTurno accionPrimero = (primero == _jugador) ? accionUsuario : accionRival;
    AccionTurno accionSegundo = (segundo == _jugador) ? accionUsuario : accionRival;
    
    print("\n--- INICIO TURNO (Primero: ${primero.nombre}, Segundo: ${segundo.nombre}) ---");

    print("-> Acción de ${primero.nombre}:");
    _ejecutarAccion(primero, accionPrimero);
    
    if (_jugador.vida <= 0 || _rival.vida <= 0) { 
      finBatalla(); 
      return; 
    }

    if (segundo.vida > 0) {
      print("\n-> Acción de ${segundo.nombre}:");
      _ejecutarAccion(segundo, accionSegundo);
    }

    //daño Residual 
    print("\n--- Fase de Daño Residual ---");
    if (_jugador.vida > 0) _jugador.finDeTurno(); 
    if (_rival.vida > 0) _rival.finDeTurno();

    finBatalla();
  }
  
  void finBatalla() {
    if (_jugador.vida <= 0 || _rival.vida <= 0) {
      _enCurso = false;
      print("\n--- ¡BATALLA TERMINADA! ---");
      if (_jugador.vida > 0) {
        print("¡VICTORIA! Ganó ${_jugador.nombre}.");
      } else {
        print("DERROTA. Ganó ${_rival.nombre}.");
      }
    }
  }

  void iniciarBatallaLucha() {
    _seleccionarPersonaje();
    _seleccionarRival();

    print("\n--- ¡BATALLA LISTA! COMIENZA EL COMBATE ---");

    while (enCurso) {
      
      //Turno del Jugador
      print("\n=======================================================");
      print("TURNO DE ${_jugador.nombre} (HP: ${_jugador.vida.toStringAsFixed(0)}/${_jugador.vidaMax.toStringAsFixed(0)}, Estado: ${_jugador.estadoActual})");
      print("RIVAL: ${_rival.nombre} (HP: ${_rival.vida.toStringAsFixed(0)}/${_rival.vidaMax.toStringAsFixed(0)}, Estado: ${_rival.estadoActual})");
      print("=======================================================");

      stdout.write("Elige una acción (1. Atacar con ${_jugador.misAtaques[0].nombreAtaque}): ");
      stdin.readLineSync(); 
      AccionTurno accionUsuario = AccionAtacar(_jugador.misAtaques[0]);
      
      //turno del Rival
      String decisionRivalStr = _iaRival.tomarDecision(_rival, _itemsRivalActuales);
      AccionTurno accionRival = _convertirDecisionRival(decisionRivalStr);
      
      //ejecutar el Turno
      determinarTurno(accionUsuario, accionRival);

      
    }
  }
}