package com.example.pokemon_battle_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
